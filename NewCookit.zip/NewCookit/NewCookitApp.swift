//
//  NewCookitApp.swift
//  NewCookit
//
//  Created by Riyad Abed on 5/9/23.
//

import SwiftUI

@main
struct NewCookitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
