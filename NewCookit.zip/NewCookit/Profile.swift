//
//  Profile.swift
//  NewCookit
//
//  Created by Riyad Abed on 5/9/23.
//

import SwiftUI

struct Profile: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
